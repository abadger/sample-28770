from distutils.core import setup

setup(name='local_helpers',
      version='1.0',
      packages=['local_helpers'],
    )
